#include "apc.h"

// Author: Suprith Y
// Description: Main driver program to perform big integer operations (+, -, x, /) using linked lists.

int main(int argc, char *argv[])
{
    node *head1 = NULL, *tail1 = NULL, *head2 = NULL, *tail2 = NULL, *headR = NULL, *tailR = NULL; // operand and result lists

    cla_validation(argc,argv); // validate inputs

	int sign1 = 1, sign2 = 1; // sign flags

	if (argv[1][0] == '-') // check sign of operand1
	{
    	sign1 = -1;
    	argv[1]++;   // skip '-'
	}

	if (argv[3][0] == '-') // check sign of operand2
	{
    	sign2 = -1;
    	argv[3]++;   // skip '-'
	}

	create_list(argv[1],&head1,&tail1); // create list for operand1
	create_list(argv[3],&head2,&tail2); // create list for operand2

    char oper = argv[2][0]; // operator

    switch(oper)
    {
	case '+':
	{
    	if (sign1 == sign2) // same sign → addition
    	{
        	addition(tail1, tail2, &headR, &tailR);

        	if (sign1 == -1)
            	printf("-");
    	}
    	else // different signs → subtraction
    	{
        	int ret = compare_list(head1, head2);

        	if (ret == OPERAND1)
        	{
            	subtraction(tail1, tail2, &headR, &tailR);
            	if (sign1 == -1)
                	printf("-");
        	}
        	else if (ret == OPERAND2)
        	{
            	subtraction(tail2, tail1, &headR, &tailR);
            	if (sign2 == -1)
                	printf("-");
        	}
        	else
        	{
            	printf("0\n");
            	break;
        	}
    	}

    	print_list(headR); // print result
    	break;
	}
	case '-':
	{
    	if (sign1 != sign2) // different signs → addition
    	{
        	addition(tail1, tail2, &headR, &tailR);

        	if (sign1 == -1)
            	printf("-");
    	}
    	else // same signs → subtraction
    	{
        	int ret = compare_list(head1, head2);

        	if (ret == OPERAND1)
        	{
            	subtraction(tail1, tail2, &headR, &tailR);
            	if (sign1 == -1)
                	printf("-");
        	}
        	else if (ret == OPERAND2)
        	{
            	subtraction(tail2, tail1, &headR, &tailR);
            	if (sign1 == 1)
                	printf("-");
        	}
        	else
        	{
            	printf("0\n");
            	break;
        	}
    	}

    	print_list(headR); // print result
    	break;
	}
	case 'x':
	case 'X':
    {
    	multiplication(tail1, tail2, &headR, &tailR); // multiplication

    	if (sign1 != sign2)
        	printf("-");

    	print_list(headR);
    	break;
	}
	case '/':
	{
    	if (head2->data == 0 && head2->next == NULL) // division by zero check
    	{
        	printf("Division by zero error\n");
        	break;
    	}

    	division(head1, tail1, head2, tail2, &headR, &tailR); // division

    	if (sign1 != sign2)
        	printf("-");

    	print_list(headR);
    	break;
	}
	default:
	    printf("Invalid operator\n"); // invalid case
    }
}