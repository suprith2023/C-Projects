#include "apc.h"

// Author: Suprith Y
// Description: Validates input, creates and manages doubly linked lists for big integer operations.

// Function prototypes
int is_number(char *);


// Validate command line arguments
int cla_validation(int argc, char *argv[])
{
    if(argc != 4) // check argument count
    {
        printf("INVALID INPUT\n");
        return FAILURE;
    }

    // check valid operator
    if ((argv[2][0] != '+' && argv[2][0] != '-' &&
         argv[2][0] != 'x' && argv[2][0] != '/') || argv[2][1] != '\0')
    {
        printf("INVALID OPERATOR\n");
        return FAILURE;
    }

    return SUCCESS;
}


// Check if string is a number
int is_number(char *str)
{
    int i = 0;

    if(str[0] == '\0') // empty string check
    {
        return 0;
    }

    while(str[i] != '\0')
    {
        if(!isdigit(str[i])) // non-digit check
        {
            return 0;
        }
        i++;
    }

    return 1;
}


// Create list from operand string
void create_list(char *opr, node **head, node **tail)
{
    *head = NULL;
    *tail = NULL;

    for(int i = 0; opr[i] != '\0'; i++)
    {
        if(insert_last(head, tail, opr[i] - '0') == FAILURE) // insert digits
        {
            printf("Operation Failed\n");
            return;
        }
    }
}


// Insert node at end
int insert_last(node **head, node **tail, int data)
{
    node *new = malloc(sizeof(node));

    if (new == NULL) // memory check
    {
        return FAILURE;
    }

    new->prev = NULL;
    new->data = data;
    new->next = NULL;

    if (*head == NULL) // first node
    {
        *head = new;
        *tail = new;
    }
    else
    {
        (*tail)->next = new;
        new->prev = *tail;
        *tail = new;
    }

    return SUCCESS;
}


// Insert node at beginning
int insert_first(node **head, node **tail, int data)
{
    node *new = malloc(sizeof(node));

    if (new == NULL)
    {
        return FAILURE;
    }

    new->data = data;
    new->prev = NULL;
    new->next = NULL;

    if (*head == NULL) // empty list
    {
        *head = new;
        *tail = new;
    }
    else
    {
        new->next = *head;
        (*head)->prev = new;
        *head = new;
    }

    return SUCCESS;
}


// Print list
void print_list(node *head)
{
    if (head == NULL) // empty check
    {
        printf("INFO : List is empty\n");
        return;
    }

    while (head != NULL)
    {
        printf("%d", head->data); // print digit
        head = head->next;
    }
    printf("\n");
}


// Get list length
int list_len(node *head)
{
    node *ptr = head;
    int count = 0;

    while (ptr != NULL)
    {
        count++;
        ptr = ptr->next;
    }
    
    return count;
}


// Compare two lists
int compare_list(node *head1, node *head2)
{
    int list1_len = list_len(head1);
    int list2_len = list_len(head2);

    node *temp1 = head1;
    node *temp2 = head2;

    if (list1_len > list2_len)
    {
        return OPERAND1;
    }
    else if (list1_len < list2_len)
    {
        return OPERAND2;
    }
    else
    {
        while (temp1 != NULL)
        {
            if (temp1->data > temp2->data)
            {
                return OPERAND1;
            }
            else if (temp1->data < temp2->data)
            {
                return OPERAND2;
            }
            else
            {
                temp1 = temp1->next;
                temp2 = temp2->next;
            }
        }
        
        return SAME; // equal lists
    }
}


// Delete entire list
int delete_list(node **head, node **tail)
{
    if (*head == NULL)
    {
        return FAILURE;
    }

    node *temp = *head;

    while (temp != NULL)
    {
        node *next = temp->next;
        free(temp); // free node
        temp = next;
    }

    *head = NULL;
    *tail = NULL;

    return SUCCESS;
}


// Remove leading zeros
void remove_pre_zeros(node **head)
{
    if (*head == NULL)
    {
        return;
    }

    node *temp = *head;

    while (temp->data == 0 && temp->next != NULL) // skip leading zeros
    {
        *head = temp->next;
        (*head)->prev = NULL;
        free(temp);
        temp = *head;
    }
}