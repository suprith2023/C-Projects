#include "apc.h"

// Author: Suprith Y
// Description: Subtracts two large numbers using linked lists and stores the result.

void subtraction(node *tail1, node *tail2, node **headR, node **tailR)
{
    node *temp1 = tail1;
    node *temp2 = tail2;

    int borrow = 0; // borrow for subtraction
    int num;

    *headR = NULL;
    *tailR = NULL;

    while (temp1 != NULL || temp2 != NULL) // traverse both lists
    {
        int val1 = 0, val2 = 0;

        if (temp1 != NULL)
        {
            val1 = temp1->data;
            temp1 = temp1->prev;
        }

        if (temp2 != NULL)
        {
            val2 = temp2->data;
            temp2 = temp2->prev;
        }
        
        num = val1 - val2 - borrow; // subtract digits

        if (num < 0) // handle borrow
        {
            num += 10;
            borrow = 1;
        }
        else
        {
            borrow = 0;
        }

        insert_first(headR, tailR, num); // store result digit
    }

    while (*headR && (*headR)->data == 0 && (*headR)->next != NULL) // remove leading zeros
    {
        node *temp = *headR;
        *headR = (*headR)->next;
        (*headR)->prev = NULL;
        free(temp);
    }
}