#include "apc.h"

// Author: Suprith Y
// Description: Adds two large numbers represented as doubly linked lists and stores the result in another list.

void addition(node *tail1, node *tail2, node **headR, node **tailR)
{
    int carry = 0, sum, digit; // carry for overflow, sum for addition, digit to store result digit

    node *temp1 = tail1; // pointer to traverse first list from tail
    node *temp2 = tail2; // pointer to traverse second list from tail

    *headR = NULL; // initialize result list head
    *tailR = NULL; // initialize result list tail

    while (temp1 != NULL || temp2 != NULL) // loop until both lists are fully traversed
    {
        sum = carry; // start sum with previous carry

        if (temp1 != NULL) // if first list has nodes
        {
            sum += temp1->data; // add digit from first list
            temp1 = temp1->prev; // move to previous node
        }

        if (temp2 != NULL) // if second list has nodes
        {
            sum += temp2->data; // add digit from second list
            temp2 = temp2->prev; // move to previous node
        }

        digit = sum % 10; // extract last digit of sum
        carry = sum / 10; // calculate carry

        insert_first(headR, tailR, digit); // insert digit at beginning of result list
    }

    if (carry > 0) // if carry remains after loop
    {
        insert_first(headR, tailR, carry); // add carry to result list
    }

    // print_list(*headR); // optional: display the result list
}