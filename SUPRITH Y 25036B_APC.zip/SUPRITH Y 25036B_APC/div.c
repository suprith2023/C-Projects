#include "apc.h"

// Author: Suprith Y
// Description: Performs division of two large numbers using linked lists and stores the quotient in result list.

void division(node *head1, node *tail1, node *head2, node *tail2, node **headR, node **tailR)
{
    node *head_OPR1 = NULL; // temporary dividend list
    node *tail_OPR1 = NULL;

    node *l1_temp = head1; // pointer to traverse first operand

    insert_last(&head_OPR1, &tail_OPR1, l1_temp->data); // initialize temp list
    l1_temp = l1_temp->next;

    while (compare_list(head_OPR1, head2) == OPERAND2) // build initial divisible part
    {
        insert_last(&head_OPR1, &tail_OPR1, l1_temp->data);
        l1_temp = l1_temp->next;
    }

    while (l1_temp != NULL || compare_list(head_OPR1, head2) != OPERAND2) // division loop
    {
        int sub_count = 0; // quotient digit

        int cmp;
        while ((cmp = compare_list(head_OPR1, head2)) == OPERAND1 || cmp == SAME) // repeated subtraction
        {
            node *head_SR = NULL;
            node *tail_SR = NULL;

            subtraction(tail_OPR1, tail2, &head_SR, &tail_SR); // subtract divisor

            delete_list(&head_OPR1, &tail_OPR1); // clear old list

            head_OPR1 = head_SR; // update remainder
            tail_OPR1 = tail_SR;

            sub_count++; // count how many times subtraction happens
        }

        insert_last(headR, tailR, sub_count); // store quotient digit

        if (l1_temp != NULL) // bring down next digit
        {
            insert_last(&head_OPR1, &tail_OPR1, l1_temp->data);
            l1_temp = l1_temp->next;
        }

        remove_pre_zeros(&head_OPR1); // remove leading zeros
    }
    
    remove_pre_zeros(headR); // clean final result
}