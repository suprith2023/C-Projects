#include "apc.h"

// Author: Suprith Y
// Description: Multiplies two large numbers using linked lists and stores the result.

void multiplication(node *tail1, node *tail2, node **headR1, node **tailR1)
{
    node *headR2 = NULL, *tailR2 = NULL; // partial result
    node *head_AR = NULL, *tail_AR = NULL; // addition result

    node *temp1, *temp2 = tail2; // traversal pointers
    int count = 0; // position counter

    *headR1 = NULL;
    *tailR1 = NULL;

    while (temp2 != NULL) // for each digit of second number
    {
        int carry = 0;
        int num = temp2->data; // current digit

        temp1 = tail1;

        headR2 = NULL;
        tailR2 = NULL;

        for (int i = 0; i < count; i++) // add zeros (place shift)
        {
            insert_first(&headR2, &tailR2, 0);
        }

        while (temp1 != NULL) // multiply with first number
        {
            int result = carry + (temp1->data * num);

            carry = result / 10;
            result = result % 10;

            insert_first(&headR2, &tailR2, result);

            temp1 = temp1->prev;
        }

        if (carry > 0) // remaining carry
        {
            insert_first(&headR2, &tailR2, carry);
        }

        if (*headR1 == NULL) // first iteration
        {
            *headR1 = headR2;
            *tailR1 = tailR2;

            headR2 = NULL;
            tailR2 = NULL;
        }
        else if (headR2 != NULL) // add partial results
        {
            addition(*tailR1, tailR2, &head_AR, &tail_AR);

            delete_list(headR1, tailR1);
            delete_list(&headR2, &tailR2);

            *headR1 = head_AR;
            *tailR1 = tail_AR;

            head_AR = NULL;
            tail_AR = NULL;
        }

        count++; // shift position
        temp2 = temp2->prev;
    }

    if (*headR1 == NULL) // handle zero case
    {
        insert_first(headR1, tailR1, 0);
    }

    remove_pre_zeros(headR1); // clean result
}