#include "invert.h"

// Validateing the commend line arguments
int validate_cla(int argc, char *argv[], flist **head_f_list)
{
    if(argc < 2)
    {
        return FAILURE;
    }

    for(int i = 1; i < argc; i++)
    {
        if(strstr(argv[i], ".txt") != NULL)
        {
			flist *temp = *head_f_list;
			int isduplicate = 0;

			while(temp != NULL)
			{
				if(strcmp(argv[i], temp->data) == 0)
				{
					isduplicate = 1;
					break;
				}
				temp = temp->link;
			}

			if(!isduplicate)
			{
				if(insert_first(argv[i], head_f_list) == FAILURE)
				{
					return FAILURE;
				}
			}
			else
			{
				fprintf(stderr, "Warning: skipping duplicate file: %s\n", argv[i]);
			}
        }
    }

	return SUCCESS;
}

// Checking the file empty or not
int istextpresent(char *filename)
{
	FILE *fptr;
	if((fptr = fopen(filename, "r")) == NULL)
	{
		fprintf(stderr, "Could not open file: %s\n", filename);
		return FAILURE;
	}

	fseek(fptr, 0, SEEK_END);
	long size = ftell(fptr);
	fclose(fptr);

	if(size == 0)
	{
	   fprintf(stderr, "File is empty: %s\n", filename);
	   return FAILURE;
	}
		
 return SUCCESS;

}

//inserting first
int insert_first(char *filename, flist **head_f_list)
{
	if(istextpresent(filename) == FAILURE)
	{
		return FAILURE;
	}

	flist *new_node = malloc(sizeof(flist));
	if(!new_node)
		return FAILURE;
	
	new_node->data = malloc(strlen(filename) + 1);
    if(!new_node->data)
    {
        free(new_node);
        return FAILURE;
    }
	strcpy(new_node->data, filename);
	new_node->link = NULL;
	if(*head_f_list == NULL)
	{
		*head_f_list = new_node;
		return SUCCESS;
	}
	else
	{
		new_node->link = *head_f_list;
		*head_f_list = new_node;
		return SUCCESS;
	}
}

// Printing the file names list
void print_list(flist **head_f_list)
{
	if(*head_f_list == NULL)
	{
		printf("ERROR : LIST IS EMPTY\n");
		return;
	}

	flist *temp = *head_f_list;
	printf("head ->");

	while(temp != NULL)
	{
		printf(" %s->", temp->data);
		temp = temp->link;
	}

	printf(" NULL\n");
}

// Hash table creation
void insert_ht(ht_arr *table)
{
	for(int i = 0; i < TABLE_SIZE; i++)
	{
		table[i].index = i;
		table[i].head = NULL;
	}

	printf("HashTable is successfully created\n");
}

// Validateing the file name
void validate_files(ht_arr *h_table, flist **head_f_list)
{
	for(int i = 0; i < TABLE_SIZE; i++)
	{
		if(h_table[i].head == NULL)
		{
			continue;
		}

		m_node *mtemp = h_table[i].head;
		while(mtemp != NULL)
		{
			s_node *stemp = mtemp->s_link;
			while(stemp != NULL)
			{
				flist *temp = *head_f_list;
				while(temp != NULL)
				{
					flist *next = temp->link;
					if(strcmp(stemp->f_name, temp->data) == 0)
					{
						delet_elemtent(head_f_list, stemp->f_name);
						break;
					}
					temp = next;
				}
				stemp = stemp->link;
			}
			mtemp = mtemp->m_link;
		}
	}
}

void delet_elemtent(flist **head_f_list, char *data)
{
	flist *temp = *head_f_list;
	flist *pre = NULL;

	while(temp != NULL)
	{
		if(strcmp(temp->data, data) == 0)
		{
			if(temp == *head_f_list)
			{
				*head_f_list = temp->link;
			}
			else
			{
				pre->link = temp->link;
			}
			free(temp);
			return;
	    }
		pre = temp;
		temp = temp->link;
	}
}