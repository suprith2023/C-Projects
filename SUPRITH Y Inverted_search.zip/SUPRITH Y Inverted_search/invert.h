#ifndef INVERT_H
#define INVERT_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define SUCCESS 0
#define FAILURE 1
#define TABLE_SIZE 28
#define MAGIC_STRING "&&**"

typedef struct sub_node
{
    int w_count;
    char *f_name;
   struct sub_node *link;
}s_node;

typedef struct main_node
{
    char *word;
    int f_count;
    s_node *s_link;
    struct main_node *m_link;
    
}m_node;

typedef struct hash_arra
{
    int index;
    m_node *head;
}ht_arr;

typedef struct f_list
{
    char *data;
    struct f_list *link;
}flist;

// Mainly need Prototypes...
void insert_ht(ht_arr *table);
int validate_cla(int argc, char *argv[], flist **head_f_list);
int istextpresent(char *filename);
int insert_first(char *filename, flist **head_f_list);
void print_list(flist **head_f_list);

// Createing the data base prototypes...
int create_db(ht_arr *ht_table, flist *head);
int insert_word(ht_arr * ht_table, const char *word, const char *filename);
int index_find(const char ch);

// Display the data base prototypes...
void display_table(ht_arr *table);

int search_db(ht_arr *ht_table);
int save_db(ht_arr *h_table);

int update_db(ht_arr *h_table);
void validate_files(ht_arr *h_table, flist **head_f_list);
void delet_elemtent(flist **head_f_list, char *data);
#endif