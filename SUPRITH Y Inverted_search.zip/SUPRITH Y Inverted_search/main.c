/* Name : Suprith Y
 * Description: to implement inverted search using hash table and linked list which will store the word and the file name in which the word is present and also count of the word in that file.
 * Date : 20-04-2026
 */



#include "invert.h"

int main(int argc, char *argv[])
{
    flist *head_f_list = NULL;

    ht_arr h_table[TABLE_SIZE];
    insert_ht(h_table);

    int Cflag = 0;
    int Uflag = 0;

    if(validate_cla(argc, argv, &head_f_list)== FAILURE)
    {
        printf("Entered argument error\n");
        return FAILURE;
    }
    else
    {
        print_list(&head_f_list);
    }

    int choise;
    do{
        printf("1.create_db\n2.Display_db\n3.save_db\n4.search_db\n5.update_db\n6.Exit...\n");

        printf("Enter the choice : ");
        scanf("%d", &choise);

        switch(choise)
        {
            case 1:
                //callout the create_db
                if(Cflag == 0)
                {
                    if(Uflag == 1)
                    {
                        validate_files(h_table, &head_f_list);
                        print_list(&head_f_list);

                    }

                    if(create_db(h_table, head_f_list) == SUCCESS)
                    {
                        printf("Database created......\n");
                        Cflag = 1;
                    }
                }
                else
                {
                    printf("data base can be created only once......\n");
                }
                break;
            
            case 2:
                //callout the display_db
                display_table(h_table);
                break;
            
            case 3:
                //callout the save_db
                if(Cflag == 1)
                {
                  if(save_db(h_table) ==   SUCCESS)
                  {
                    printf("Save fuction is successfull....\n");
                  }
                }
                else
                {
                   printf("ERROR :  Save function is not possible Before the create function....\n");
                }
                break;
            
            case 4:
                //callout the search_db
                if(search_db(h_table) == SUCCESS)
                {
                    printf("Searching Data base is Successfull....\n");
                }
                break;

            case 5:
                //callout the update_db
                update_db(h_table);
                Uflag = 1;
                break;

            case 6:
                printf("Exiting for the program....\n");
                return SUCCESS;
            
            default:
                printf("Invalid input..\n");
        }
        
    }while(choise != 6);
}