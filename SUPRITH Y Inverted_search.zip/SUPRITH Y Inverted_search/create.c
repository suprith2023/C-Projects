#include "invert.h"

int create_db(ht_arr *ht_table, flist *head)
{
    flist *temp = head;
    char word[20];
    while(temp != NULL)
    { 
        FILE *fp = fopen(temp->data, "r");
        if(fp != NULL)
        {
            while(fscanf(fp, "%s", word) == 1)
            {
                if(insert_word(ht_table, word, temp->data) == FAILURE)
                {
                    return FAILURE;
                }
            } 
            fclose(fp); 
        }
        else
        {
            return FAILURE;
        }
        temp = temp->link;
    }

    return SUCCESS;
}

int index_find(const char ch)
{
    if(ch >= 'a' && ch <= 'z')
    {
        return ch - 'a';
    }
    else if(ch >= 'A' && ch <= 'Z')
    {
        char lower = tolower(ch);
        return lower - 'a';
    }
    else if(isdigit(ch))
    {
        return 26;
    }
    else
    {
        return 27;
    }
}
int insert_word(ht_arr * ht_table, const char *word, const char *filename)
{
    int index = index_find(word[0]); 
    m_node *main = ht_table[index].head;

    while(main != NULL){
        if(strcmp(word, main->word) == 0)
        {
           s_node *sub = main->s_link;
           
          while(sub != NULL)
          {  
            if(strcmp(filename, sub->f_name) == 0)
            {
                sub->w_count++;
                return SUCCESS;
            } 
            sub = sub->link;
          }

          // File not found, add new sub-node
          s_node *new_subnode = malloc(sizeof(s_node));
          if(!new_subnode)
          {
            printf("Subnode Dynamical allocation is Failed\n");
            return FAILURE;
          }
          new_subnode->f_name = strdup(filename);
          new_subnode->w_count = 1;
          new_subnode ->link = main->s_link;
          main->s_link = new_subnode;
          main->f_count++;
          return SUCCESS;
        }
       main = main->m_link;
    }

    // Word not found, create new main node
    m_node *new_Mnode = malloc(sizeof(m_node));
    if(!new_Mnode)
    {
        printf("mainnode Dynamical allocation is Failed\n");
        return FAILURE;
    }
    
    new_Mnode->word = strdup(word);
    new_Mnode->f_count = 1;
    
    //create a new subnode
    s_node *new_Snode = malloc(sizeof(s_node));
        if(!new_Snode){
        printf("Subnode Dynamical allocation is Failed\n");
        return FAILURE;
    }

    new_Snode->f_name = strdup(filename);
    new_Snode->w_count = 1;
    new_Snode->link = NULL;

    new_Mnode->s_link = new_Snode;
    new_Mnode->m_link = ht_table[index].head;
    ht_table[index].head = new_Mnode;

    return SUCCESS;
}